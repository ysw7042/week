package com.week4;

import java.util.Calendar;

public class Test3 {

	public static void main(String[] args) {
		
//		Data ob = new Data();
//		ob.print();
		
		Data.getInstance();
		
		Calendar now1 = Calendar.getInstance();
		Calendar now2 = Calendar.getInstance();
		Calendar now3 = Calendar.getInstance();
		
		
		
	}

}




