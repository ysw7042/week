package com.score;

public class Scoremain {
	public static void main(String[] args) {
		
		Score ob = new Score();
		
		ob.set();
		
	}
}
