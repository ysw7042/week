package com.score;

public class Record {

	String name;
	int kor,eng,mat;
	int tot,ave,rank;
	
}
