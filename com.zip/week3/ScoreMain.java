package com.week3;

import com.score.Score;

public class ScoreMain {

	public static void main(String[] args) {
		
		Score ob = new Score(); 
		
		
		ob.set();
		ob.input();
		//ob.ranking();
		ob.print();
		
		
		
		
	}

}
