package com.week3;

public class Test4 {
	public static void main(String[] args) {
		
		int i,j;
		
		int number = 5;
	
		for(i=0;i<number-1;i++) {//Selection Sort ����
			
			for(j=i+1;j<number;j++) {
			
				System.out.println(i + ":"+ j);
				
			}
		}
	}
}